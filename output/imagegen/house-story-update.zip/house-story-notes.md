# After Bells House story update

17 November 2026.

## Editorial references

Official pages reviewed for structure and tone:

- [Amouage — Our Story](https://amouage.com/en-uk/pages/our-story): a house identity rooted in place, followed by its approach to materials and craft.
- [Creed — About the House](https://creedboutique.com/pages/about-us): one central idea connects the house's history, discipline and approach to fragrance.
- [Clive Christian — About](https://www.clivechristian.com/about): a clear creative position supported by standards and the character of its perfumes.
- [Louis Vuitton — World of Fragrances](https://uk.louisvuitton.com/eng-gb/stories/world-of-fragrances): emotional experience leads into the creative world and materials behind the perfumes.

The After Bells copy is original. Its identity comes from the existing brand concept of the hour after the bells, expressed through dusk, dawn and midnight. No founding dates, founder biography, historical pedigree, royal associations or place of manufacture were added.

## Selected campaign image

`house-model-ritual-v1.png`: an original campaign photograph generated with the built-in image tool. It shows a fictional adult woman applying Amber Hour to her neck. The supplied Amber Hour product sheet informed the bottle. The earlier static portrait is an unused alternative.

Web asset: `public/media/house-model-ritual-v1.webp`.
Exact prompt and source provenance: `house-model-ritual-v1-prompt.json`.

## Live page copy

### The House of After Bells

Some hours stay with you.

Perfume for the moments that linger. The warmth of dusk, the openness of dawn, the depth of midnight.

### The story of After Bells — The hour is yours.

A familiar street at dusk. A conversation that runs past midnight. The first breath of a new day.

After Bells takes its name from the pause after the bells: when the noise settles and a moment begins to feel entirely your own. We compose for that change of rhythm.

Our First Edition gives it three expressions. Amber Hour holds the warmth of evening. Open Sky opens onto the clarity of dawn. Iron Crown brings the depth of midnight. Each is universal, made to be chosen by feeling.

## Copy and layout changes

- A model applying perfume leads the page beside the headline on desktop, with the photo above the copy on phones.
- A separate story section develops the name and the three fragrance moods.
- The label chapter is removed. The craft sequence now covers composition, gold and the cap.
- Label dimensions are removed from the House page, product hero benefits, product finishing copy and shared catalogue text.
- The portrait displays at a maximum of 512 CSS pixels wide, within its native 1024-pixel width for 2× displays. The 4:5 mobile crop retains the face, hand and perfume bottle.
